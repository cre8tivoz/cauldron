# Cauldron pivot — initial reference read

Working brief: [[WEB BUILDER IDEAS]]. Original note preserved.

## Current development record — 7 Nov 2026

**Application development is paused.** Billy authorised a documentation/process audit. The existing plan, approved taste checks and decisions remain the authority; current document edits have not been committed or pushed.

- Repository: https://github.com/cre8tivoz/cauldron
- Code: `/Users/habibi/hermes/apps-codebases/cauldron`; pushed checkpoint `82fc6c6cd38f9181332dfc2ef4c0bcddc95f8528` on `main`.
- Research entry point: `/Users/habibi/hermes/apps-codebases/cauldron-astro/START-HERE.md`.
- Current 24-item requirement/evidence map, issue/risk register and limitations: app `docs/plan-verification.md`.
- Local tracker: app `.scratch/cauldron-v1/spec.md`, one retrospective finding per file under `issues/`. All records need triage; none authorises application work.
- CI run https://github.com/cre8tivoz/cauldron/actions/runs/42316697137 completed successfully, including ZIP download/unpack/launch on a fresh macOS runner.

**Verified checkpoint:** both editor copies 23/23; both component-library copies 11/11; rudeboycoffee content 6/6; both quality harnesses 9/9. The sites themselves still have 9 and 15 quality failures respectively. Claude passes 12/12 through Cauldron, including a real MCP edit and conversation resume. Generic smoke shutdown warnings and 16 moderate development/build dependency findings remain open.

**Process audit:** the configured local Markdown tracker had no tickets during implementation; GitHub had no issues. After the earlier approval timeout, Billy returned and requested resubmission. The five-file instruction patch succeeded: both workspaces now identify the local Markdown tracker and the app finding records, and preserve the implementation pause. Finding 00 retains the historical process failures and awaits triage. Eight ADRs and the glossary match across both workspaces. Some research lessons were implemented, while phase acceptance and traceability were inconsistently maintained. The blind-test preparation added conditions beyond the agreed plan; those run-sheet additions have been removed. Its two illustrative drafts still lack real-brief provenance.

**Still open:** full acceptance evidence, remaining save/recovery and shared-action paths, Codex/Hermes revised multi-turn support, complete Before/After and UI coverage, all approved taste/library criteria, remote publishing and manual unsigned first launch, and the four real-brief comparison builds with Billy's blind judgement. Existing issue records link each gap to the agreed plan. The 4.5 gate continues to prevent a v1 release.

**Locked decisions:** own MIT application; Electron + React + TypeScript; design taste core; agent left/preview centre/inspector right; minimum 1280 × 800; Coral and Source Sans 3 following the Mac theme; Claude first, plus Codex and Hermes; content editing, publishing and Before/After in v1; editable plain-Astro components; seven selected directions/five components plus links. Open Design and earlier rejected sets remain excluded. Further Camillo/subagent work remains stopped. BYOK and Windows/Linux remain parked.

The historical sections below preserve the earlier investigation. Foundation-adaptation recommendations and open choices in those sections were superseded by the grilling decisions, ADRs and current development plan. They do not reopen scope or authorise an old next step. The original [[WEB BUILDER IDEAS]] note is unchanged.

## Source collection and proposed foundation

**Workspace:** `/Users/habibi/hermes/apps-codebases/cauldron-astro/`. Its `README.md` maps source roles, current implementation recommendation, Mobbin patterns and the next hands-on evaluation.

- Collected 12 clean upstream source repositories; exact commits, original URLs and licence texts in `references/source-manifest.json`. All 24 original URLs are accounted for in `references/reference-catalog.json`. Collection occupies about 928 MB; no dependency installs or app launches performed.
- Sources: Stacki, Sveltia CMS, Pages CMS, Ycode, Stageshow skills, Superdesign app, Superdesign skill, React Bits, ThreeUI community, Design Bites, OriginKit plugin and Meno Astro runtime.
- Ten have MIT root/skill licences verified. React Bits has redistribution restrictions and Superdesign app has mixed AGPL/enterprise terms; those are source-study references, excluded from automatic incorporation. Individual assets and dependencies still need review.
- Meno's MIT public runtime is distinct from its editor: runtime README explicitly excludes closed converter internals; editor npm metadata reports Elastic-2.0. Sitereal's published licence identifies a paid proprietary application. Retain these as public workflow references where source reuse is unavailable.
- **Recommendation:** evaluate adapting Stacki's existing Electron/React desktop editor as Cauldron Astro's foundation. It already contains a desktop shell and real Astro editing/preview machinery. A project should open into one working window and manage its own preview. Generated websites use Astro; implementing the editor in Astro is not a requirement. Existing Cauldron OS frame has no retention requirement. Runtime reliability and resource use still need hands-on testing.
- **Mobbin inspected:** [GoDaddy editor](https://mobbin.com/screens/c0047eda-bff8-4d3a-820d-dff82b2f7733) for selected-element preview + contextual right-side controls + saved status; [Canva section panel](https://mobbin.com/screens/e98b8bde-f666-4031-b93f-ab0664921f38) for section thumbnails, explicit insert/apply actions, and grouped colour/type previews. Apply to the selected-section inspector and section/design library. Full-resolution research images are saved privately under `references/mobbin/`, excluded from future app publication.
- Next technical evaluation: start Stacki against a disposable Astro site; exercise create/edit/preview/undo, external agent edits and complex source handling, window resizing and keyboard use; inspect attachment points for the design library and agent controls. Visible launch needs Billy's permission while he uses the Mac.

**Billy's decision: visual editing and agent interaction have equal prominence.** Both work on the same site and selection, remain readily available, and reflow through resizable/collapsible panels at smaller window sizes.

**Billy's decision: Electron is locked in for the first application version.** Integrated agent operation should make the app self-contained for everyday work, with external-agent access available too. Plan Mac distribution around unsigned downloads plus first-launch approval while there is no Apple Developer membership. Stacki source evaluation proceeds within this framework decision.

### Foundation source review completed

Detailed report: `/Users/habibi/hermes/apps-codebases/cauldron-astro/FOUNDATION-ASSESSMENT.md`.

- **Recommendation:** adapt Stacki's Electron editor as a connected foundation. Retain project/preview lifecycle, source-aware page editing, selection context, existing content/style/asset tools and undo/conflict machinery.
- **Verified source risk:** stylesheet edits pass an original `base` from the visual editor, but the desktop request contract/handler omit it. An old draft can overwrite newer external stylesheet edits. Reproduce this with a concurrent-edit/undo test before relying on integrated agents.
- **Agent design:** use Ycode's shared-action-catalogue pattern for the same editing operations inside chat and through external tools; use HyperFrames as the connection/session/progress reference. Stacki currently copies selection context into external chats; integrated session-aware chat is new work.
- **Other sources:** content-save patterns from Pages CMS/Sveltia; explicit unsupported-source handling from Meno; curated design data from Design Bites/Stageshow and library-discovery patterns from OriginKit. These have specific roles and are not automatic dependencies.
- **Next gate (superseded):** the real-project Stacki test has since been done. See below.

### Hands-on test and REA code analysis — 6 Nov 2026

**Combined plan (draft, for the grill-me walkthrough):** `/Users/habibi/hermes/apps-codebases/cauldron-astro/CAULDRON-ASTRO-PLAN.md`. Stress-tested by Jev: it rejected all five planted false claims and backed the main findings. It added two gaps (the app's own visual polish; a testable design package) and refined the build order. Ten decisions are listed for Billy, including how to handle the Sitereal material, because Sitereal's licence forbids reverse-engineering.

**UI research (Mobbin deep dive):** `/Users/habibi/hermes/apps-codebases/cauldron-astro/CAULDRON-UI-RESEARCH.md`. Mobbin collection: [Cauldron Astro — UI research](https://mobbin.com/collections/5d511baf-5e36-4493-8171-e50f80dfaa37/mobile/screens) (private, 113 screens). Recommends the agent on the left, the live preview centre and the inspector right. Layouts are defined for five window sizes, and the website preview is scaled rather than reflowed when the window shrinks. Includes "expensive on a free budget" craft rules and seven UI decisions for the grill-me session.

Reports in `/Users/habibi/hermes/apps-codebases/cauldron-astro/`: `STACKI-RUNTIME-EVALUATION.md`, `STACKI-REA-ASSESSMENT.md`, `SITEREAL-REA-ASSESSMENT.md`, `ZEKU-REA-ASSESSMENT.md`.

- **Stacki stays the foundation, from the MIT repository only.** It opened, previewed and edited a real Astro site. The official download (0.0.23) is an older, `UNLICENSED`, HTML-only app; there is no packaged release of the Astro editor yet.
- **First repair, root cause confirmed in code:** stylesheet and source saves drop the version they were based on, so Undo applies an old stylesheet over newer changes. This was reproduced live: an outside CSS edit was lost.
- **Second repair:** a newly created page shows 404 until a manual preview reload. Cause not yet found.
- **Check before agents edit sites:** preview frames receive Stacki's preload bridge.
- **Sitereal (ideas only, proprietary):** one engine shared by visual edits and MCP agents; saves keep a baseline and merge outside edits; agent changes are grouped and undone with conflict checks.
- **Zeku (ideas only, proprietary, Tauri):** content forms from Astro schemas with a staleness flag; "keep mine / use disk" choice for unsaved files; 10-second recovery checkpoints; blocks pull/publish while files are unsaved.

**Agent integration reference: the installed HyperFrames desktop app.** Read-only inspection confirmed its agent catalogue declares Claude Code, Codex, Antigravity, OpenCode, Hermes, Copilot, Grok and OpenClaw alongside its own agent. Bundled code has per-agent event/session handling and plugin launch/version conventions. This was source inspection; integrations were not executed. Source paths and the proposed Cauldron mapping are recorded in `apps-codebases/cauldron-astro/README.md`, under “HyperFrames integration reference”. Study the shared instructions/commands, client installation, existing authentication, selected-element context, session continuity and real completion/error reporting. Treat installed app code as reference material until reuse rights are verified.

## Current direction — Billy's correction and Jev reassessment

**This section supersedes the preservation-led recommendation below.** Billy reports that current Cauldron is functionally useless/outdated and has never reliably delivered its intended workflow. The existing Alpine HTML prototype and Markdown handoff experience is the reason for the complete pivot. Existing code carries no presumption of retention or compatibility.

The product brief is **a fully free, open-source Astro site design and builder tool**. Billy now builds his websites with Astro. Design taste, speed and accessibility are core objectives. External agents must be able to operate the builder using their own model access; optional in-app BYOK remains an open feature choice.

### Revised proposal

- Create or open an actual Astro site. Work directly with its pages, layouts, components, content and assets from the first build.
- Provide a useful design/build workspace: project/page navigation, references and design direction, curated section/component discovery, actual site preview, and targeted changes to content, section order and styling. Decide the editing controls by exercising those tasks. Visual editing is legitimate scope.
- Give external agents a clear way to operate that same workspace and inspect changes/results. The workflow should support iterative building and refinement through a full site. Another exported prompt bundle alone would fail the brief.
- Put taste into usable decisions and materials: coherent art direction, layout/composition examples, compatible Astro components, typography, imagery, purposeful motion and responsive behaviour. Evaluate against real site briefs and contrasting styles.
- Build and check the real output for performance, accessibility, responsive behaviour and broken interactions. Astro provides a suitable foundation; individual implementations still require checks.
- Choose the architecture around this experience. Replace the old workflow completely where needed. Reuse individual assets only when demonstrably helpful. A complete rewrite is acceptable; preserving previous implementation effort is not a design goal.
- Keep free/open-source operation independent of paid design libraries or Cauldron model keys. Evaluate optional standalone BYOK on its actual usefulness.

### Jev challenge of the revised proposals

Ran 10 additional requests: seven proposed directions and three deliberately weak alternatives, each judged against the corrected brief and relevant saved project/source passages. Questions covered fit, concrete gap addressed, sufficiency alone, unproven assumptions and observable testability. These are model judgments on supplied proposal wording; technical feasibility still requires a working build. No probabilities are presented as objective architecture scores.

- Strong positive fit judgments for direct Astro building, agent-operated workspace, practical design tooling, replacement freedom and evaluating relevant existing tools.
- Very low fit judgments for keeping the old pipeline mandatory, delivering only prompts/Markdown handoff, or assuming Astro plus the existing quality grade guarantees a finished site.
- The model judged every isolated proposal insufficient to deliver the complete product by itself. The design/build/preview/revision/check loop needs to be evaluated together.
- Mixed evidence: output checks received a low direct-product-fit judgment despite a positive gap-addressed judgment. Treat checks as a supporting part of the builder; do not turn the product into a QA dashboard. Optional BYOK remained unsettled. These results are retained, not rounded into unanimous endorsement.

Usage: 10 requests, 61,682 input tokens, estimated US$0.002590644 at US$0.042/million; US$0.10 batch cap. Files in `/Users/habibi/hermes/cauldron-pivot-research/`: `reassess_pivot.py`, `jev-reassessment-inputs.json`, `jev-reassessment.jsonl`, `jev-reassessment-summary.json`. Earlier batch and evidence remain intact. No Cauldron implementation changes authorised or made.

## Locked constraints from Billy

- Cauldron is a public, fully open-source project and free to use. Any pivot or complete rewrite retains that commitment. Research is about usefulness, design quality and maintainability, not paid tiers or a proprietary product moat.
- Relevant Cauldron development notes in Obsidian and the repository are authorised inputs for the Jev assessment, alongside the competitor references. Read and supply those materials before asking it to judge; Jev does not independently browse the local vault or repository.
- Exclude credentials, unrelated private notes and third-party confidential material. External-agent use must not require BYOK; optional standalone BYOK remains an open design choice.

## Scope and evidence

First-pass public-page extraction returned content for all 24 supplied URLs. This is not an installed-product test, visual audit or licence audit. Superdesign returned only a short marketing shell; image-heavy libraries need browser inspection before ranking their actual designs. Some long pages are truncated in the extraction; full cached-page locations are retained in the evidence.

Raw extracts: `/Users/habibi/hermes/cauldron-pivot-research/source-extracts.json`.

Initial-pass baseline: clean `main`, HEAD `dff3f1b`; README and manifest reviewed. The completed source review and Jev assessment are recorded below. No Cauldron source changes.

## Main finding

“Local Astro builder that works with your own agent” is already occupied territory. Cauldron needs to demonstrate better design decisions and a simpler complete workflow, not merely external-agent support. This is a recommendation, not established market demand.

## Most relevant references

- [Stacki](https://stacki.build): site describes visual editing of existing Astro projects, real-file writes, collections, variables/classes, and conditional component props read from TypeScript. Advertises MIT/open source; verify the repository licence before reuse. Closest architectural comparator.
- [Meno](https://meno.so): explicitly says “Design visually in Meno, build with AI tools you trust”, with an agent-friendly create command. Agent independence alone is not a unique pitch.
- [Sitereal](https://sitereal.app): describes Astro source files as the output, external code edits read back onto canvas, and a separate editor metadata file not required by the generated site. Useful model for ownership; merge/round-trip reliability remains untested.
- [Stageshow](https://benji.org/stageshow): an agent skill for faux-product UI demos, not a general Astro component system. Its useful lesson is craft rules with reasons, gold examples, bad/good comparisons, and a render/inspect/fix loop. React output may be useful selectively, not as a mandatory Astro runtime.
- [Zeku](https://zeku.dev): local Astro writing tool; describes collection-schema-derived forms and preview using the project's own Astro dev server. Explicitly no built-in AI. Good content-editing separation, not a full builder competitor.
- [Sveltia](https://sveltiacms.app/en/) and [Pages CMS](https://pagescms.org): Git-backed content editing candidates to evaluate before writing our own CMS. Their pages advertise MIT licensing; integration/authentication still need checking.
- [Prosefly](https://prosefly.com): Git-based Markdown/MDX editing; published files remain in the repository, but hosted media and unpublished drafts are separate. Ownership needs checking beyond the headline.
- [Ycode](https://www.ycode.com) and [Splitleaf](https://splitleaf.eu): visual-builder/CMS workflow comparators. Do not treat them as Astro-native just because they support AI workflows.
- [Lander blocks](https://blocks.lander.studio/?category=website): Figma design blocks, not ready-to-install Astro components. Useful reference material, with reuse terms to check.
- [GradientDeck](https://ui.gradientdeck.com), [mkdir](https://mkdir.directory), [Unsection](https://www.unsection.com): research/discovery layer; a gallery listing is not permission to redistribute source or assets.
- React Bits, Subframe Motion, ThreeUI, Prompt Motion, Sparkbites, OriginKit and Superdesign: investigate individual resources for framework/runtime, reduced motion, mobile behaviour and rights before adding to a reusable library. No blanket adoption recommendation yet.
- [Templens](https://templens.com): borrow the visible desktop/mobile quality-report idea, not its displayed scores. Generate our own checks on our actual output; automated accessibility scores are not complete accessibility proof.
- [Design with Intent anti-patterns](https://designwithintent.ai/patterns/): review checklist material, not an automatic verdict that every listed pattern is always inappropriate.
- [Lexington](https://lexingtonthemes.com/pricing): now also advertises agent access to theme design systems/sections through MCP. Worth investigating as a direct comparator to an agent-consumable taste library, not just a theme shop. Paid access does not imply redistribution rights.

## Provisional product direction

**A local Astro design workshop: your agent builds ordinary Astro files using an explicit design direction; Cauldron helps you inspect, refine and verify the result.**

Keep open: optional standalone BYOK mode, as Billy specified. External-agent mode must not require BYOK. Avoid deciding whether to build a full visual canvas before checking what Stacki/Meno already solve and what integrating with them would actually permit.

Existing Cauldron documentation describes reference selection, URL research, quality checks, scaffold exports and external-agent handoff. Those are potential assets to keep, not proof that their implementation is ready for the new workflow. Source audit next should establish what is reusable versus coupled to the seven-stage blueprint/prototype pipeline.

## Useful Jev pass

Do not ask whether the startup is a good idea: that would be opinion without demand evidence. Give it saved source passages and bounded questions:

1. Does the passage explicitly support each feature claim (Astro output, external-agent entry point, local-file ownership, visual/code round trip, CMS editing)? Preserve supporting excerpts separately.
2. Which competitor claims overlap with each proposed Cauldron promise? Include “insufficient evidence”, and do not equate absent marketing copy with absent functionality.
3. Later, on actual example output: does the design follow the chosen direction and brief, or merely reuse fashionable decoration? Separate visual judgement from deterministic build/performance checks.
4. On future public user comments: which concrete problem is being described, what workaround exists, and is willingness to pay actually stated?

Use the public references plus the relevant Cauldron repository material and Obsidian development notes Billy has authorised for this assessment. Exclude credentials, unrelated private material and third-party confidential data. Save raw judgments with source paths/links, use the existing bounded ledger pattern and keep the established spend ceiling. No Jev result should be presented as market validation.

## Earlier assessment — preservation-led recommendation superseded

**Historical recommendation, superseded by Billy's correction above:** proposed an Astro-first refocus while discouraging a full rewrite and deferring a substantial visual editor. This gave excessive weight to preserving the existing implementation. Read the current direction above for the active brief.

This is Claudia's architectural recommendation, grounded in the source review and Jev's evidence tagging—not an architecture generated or validated by Jev. It remains a proposal, not approved implementation scope.

### What the existing project actually gives us

- **A keyless starting point already exists.** `routes/generation.js:628–673` accepts an externally supplied blueprint at `/api/handoff` and creates a package without invoking a model. `routes/build-agents.js:84–104` defaults to handoff-only. Preserve these useful primitives, but do not describe them as a complete agent-operated workshop.
- **The agent feedback gap was already known.** [[Cauldron OS — Bidirectional Agent Integration Scope]]:14–16,60–85 explicitly describes detached launch without reliable completion/result ingestion. The reviewed implementation still detaches and returns `launched` immediately (`lib/build-agents.js:93–140`). The common launch argument pattern is not evidence that every named agent actually works.
- **The Astro export is only a small starter.** `lib/scaffold-generator.js:278–325` writes package/config/page/styles, uses `astro: latest`, and inserts the extracted prototype body. Body extraction (`:19–21`) discards the original head; replacement styles (`:51–107`) cannot preserve arbitrary prototype design. This is not yet the native Astro workflow we want.
- **Taste currently lives mainly in instructions.** `server.js:272–287` includes blanket rules such as no purple, no pure white/black, left-aligned body content and dark-mode default. Some principles are useful, but those stylistic preferences should not become universal bans. Explicit direction and examples should govern a project.
- **The quality score cannot certify the design.** `lib/quality-scorer.js:148–205` counts markup and styling signals; `:215–257` compares neighbouring unique hex colours in source rather than the rendered text/background pairs. These are heuristics, not evidence that a page looks good or meets WCAG.
- **Astro checking needs a different target.** `lib/verification.js:205–221,255–274` leaves reference/copy/accessibility checks unconfigured when the entrypoint is not `.html`. Run checks against the built/rendered Astro site instead. Keep clear distinctions between failed, skipped and unconfigured checks. The verification routine also executes install/build/test commands (`:277–341`); it is not a read-only inspection API.

### Proposed shape

1. **The actual Astro project is canonical.** Open/create a normal repo, use its real preview, and keep pages, components, content and assets in ordinary files. A brief/design-direction file guides the work; a blueprint is not a compulsory intermediate artefact.
2. **One documented agent contract.** An external agent can discover the design references, read the selected direction, operate on the project, request previews/checks and inspect results. Start with a small shared local API/CLI surface and an agent skill. Add MCP as an adapter only if useful; do not build different business logic for each agent brand. “Any agent” means tools capable of using that documented contract, not a promise about every chat app.
3. **Taste as a portable design package.** Include a coherent direction, licensed examples, typography/spacing/colour decisions, page composition, imagery/motion guidance, and good/bad comparisons with reasons. Check the whole site, not just isolated attractive sections. Stageshow is a useful model for teaching craft, not a ready-made Astro builder.
4. **Inspection and iteration over another chat wrapper.** The human chooses direction, sees real output, targets feedback and reviews changes. The agent already has its own model access. Optional standalone BYOK stays optional and must not block external-agent mode. Cauldron being free does not make a user's chosen external model/provider free.
5. **Separate factual checks from critique.** Build, link, layout, keyboard and automated accessibility tests report concrete evidence. Visual/design critique is explicitly advisory. No synthetic overall “taste score” pretending to be proof.
6. **Integrate content editing rather than recreate it.** Investigate Sveltia/Pages CMS for client editing, Zeku for the local content workflow, and Stacki for existing Astro visual-editing capabilities. These are evaluation candidates, not chosen dependencies. Check licences and real interoperability first.

### Smallest useful proof before committing to the rebase

Use one representative small-business Astro site, then repeat with a deliberately different visual direction:

- External agent creates/opens the project with no Cauldron model key.
- It reads the design package and builds real Astro pages/components, not an embedded HTML prototype.
- The real Astro preview reflects the edits.
- Billy can request one targeted revision; the agent changes the files and Cauldron shows the result without resetting the project.
- Checks run on the built/rendered output, with source-linked findings and explicit missing checks.
- The site builds and remains editable without Cauldron. No proprietary runtime or paid design library is required.

Only after this works decide how much direct visual editing the UI needs. Keep the familiar atelier identity if it helps, but drop mandatory seven-stage navigation rather than redesigning every screen first. Existing standalone mode can remain while the new path is proved; no deletion is authorised by this assessment.

### What Jev actually did, and where it needed correction

- Completed **51 requests across 46 documents**: 24 public-page extracts, seven original project notes (excluding this derivative assessment), and 15 selected repo files. Large documents were split at line boundaries. The original eight-note folder was also reviewed separately, including this assessment note.
- Questions tagged explicit evidence for Astro output, external agents, ordinary owned files, visual/code round trips, content editing, craft guidance and verification; project sources also had a question about planned/deferred integration. These are evidence-presence judgments, not runtime certification or priority decisions.
- Raw answers correctly highlighted Sitereal's explicit round-trip claim, Stageshow's craft/check loop and the existing Cauldron integration scope. Those claims were then checked against their actual sources.
- **Source-review corrections:** Meno's “build with AI tools you trust” plus create command is relevant even though the stricter external-agent question did not flag it confidently. Stacki's styling controls/data examples are not, by themselves, proof of taste guidance despite a positive tag. Claims of source-owned files also need nuance: a local writer is not automatically an Astro source exporter. Unsupported means “not established in this extract”, never “feature absent”.
- No visual quality ranking of the component galleries was attempted. Gallery extraction, particularly Superdesign's small shell, is insufficient evidence. No competitor was installed; round-trip reliability and licences remain unverified. Paid resources can inform research but must not become mandatory or be redistributed without permission.
- **Usage:** `jev-1.14.0`, 174,579 API-reported input tokens, estimated **US$0.007332318** at US$0.042/million. Cap US$0.50; conservative preflight request reserve US$0.255. Not a verified account charge or balance. No failed calls.

Evidence folder: `/Users/habibi/hermes/cauldron-pivot-research/`

- `run_jev.py`: question wording, source selection, credential screening, bounded runner; refuses a repeat run over the existing ledger.
- `jev-inputs.json`: exact payloads with source paths and line ranges.
- `jev-results.jsonl`: raw responses and usage, one append-only entry per request.
- `jev-summary.json`: verified batch totals.
- `jev-evidence-map.json` / `.csv`: source-level evidence map. For chunked documents these expose the maximum probability across chunks: a passage-level signal, not cumulative confidence or implementation proof.

Repository remained clean at `main`, `dff3f1b`. Source-based audit only: no application launch, builds or tests performed, and no implementation changes.
